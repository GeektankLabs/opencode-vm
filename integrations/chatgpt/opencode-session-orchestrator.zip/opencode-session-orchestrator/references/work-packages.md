# Persistent Work Packages

Use a Work Package for a multi-task outcome that needs durable membership, explicit sequencing/integration, or recovery across sessions. It is a **management task**, not a new taskboard subsystem or a replacement for member tasks. Read [Worktree ownership](worktree-ownership.md) for every member's write ownership and [Board workflow](board-workflow.md) before any Board mutation.

## Assemble the package from verified tasks

The user may start with concrete task IDs, a goal/topic, or required tasks plus optional candidates.

1. Preserve the selected connector/project. Read each supplied ID directly with the discovered task tool. For a goal, search with the actual discovered query schema. `TASK_SEARCH_INCOMPLETE` is unknown coverage, not proof that no task exists.
2. Check titles/descriptions, current Board status, superseded/duplicate/transfer state where exposed, existing task documents, project/workstream scope and linked sessions. Do not infer current implementation from Board status alone.
3. Classify every candidate as a required outcome or optional candidate, and as analysis/concept, implementation, verification/review, integration or external acceptance. Identify known prerequisite tasks, expected baseline/versions, shared files/packages/submodules/generated assets and work that must follow a consolidated HEAD. Mark unknown conflicts as unknown; do not call the tasks independent without evidence.
4. Propose members and explicit exclusions to the user, explaining any dependency or duplicate finding. Reuse existing cards for the same outcome; do not create one package per agent step. Board search/read is read-only. Create or change a package/member/link only within the user's confirmed Board mutation scope.
5. A confirmed package creation uses the actual discovered Board Project and task-creation schema. The package description should state its independent orchestration outcome, member `task_id`s, exclusions and high-level acceptance. Keep detailed evolving status in the package C/P, not by replacing the entire Board description on every turn.

A package may exist in Board `todo` while members need concept work, decisions, missing C/P, baseline inspection or external prerequisites. Record these as explicit readiness gaps, with owner and next evidence. Do not move it into execution just to begin that preparation.

If a candidate is `done`, retain it when its implementation/commit is still a required integration input. If superseded or transferred, preserve the exact stable ID and known resolution; do not silently revive or duplicate it. If a task is outside the selected project, its connection/document content is unavailable, or task search is incomplete, report the gap before finalizing membership.

## Initialize and persist the management task

The package has its own stable Board `task_id`, Compact Context and Concept Plan at the normal task-ID paths:

```text
.opencode/tasks/task-<package_task_id>.compact.md
planning/task-concepts/<package_task_id>-concept-plan.md
```

The plan contains the goal/scope, member and exclusion rationale, dependencies, ownership/worktree plan, version/shared-hunk map, integration target, waves, operator boundaries, acceptance and cleanup. The compact context is the short current snapshot: per-member Board state, session/message/result evidence, worktree/base/HEAD/commit/dirty state, implementation/integration/acceptance state, blockers and next safe management action. Keep the two roles distinct; do not paste histories/logs or the full plan into C.

Apply repository-wide ownership across packages as described in [Worktree ownership](worktree-ownership.md#choose-one-owner-and-one-working-copy). A second package referencing an active member does not acquire permission to start it again or write its tree/index. Record the existing execution owner and consume its results. One document owner serializes package C/P and publication of member deltas to the canonical connector document root; private worktree copies are not registered canonical state. See [document publication](worktree-ownership.md#publish-task-documents-without-a-second-writer).

On the authorized package transition, use the existing document lifecycle: leave Board `todo`; create/reconcile both files, exact header readback and correlated `CONCEPT_READY`; register with discovered `add_task_document_bindings` if present, otherwise `register_task_document` only when the bundle tool is absent; read both as `available` with exact paths/revisions (`REGISTERED`). Do not fall back after a bundle error. **For a package, apply the readiness gate below after `REGISTERED` and before the separate Board move.** If not ready, preserve the registered documents and leave the package in `todo`; a later authorized readiness transition reuses them. Move the Board only after the gate passes and read back status (`BOARD_MOVED`). Uncertain writes require the existing readback/recovery rules, not blind retries. See [Initialization follow-through](initialization-follow-through.md).

No package-specific MCP fields are needed: use task description for stable outcome/membership, C/P for the full working state, existing task/session links for supported evidence references, and original messages/files/Git reads for claims. If direct task-document tools are absent, keep to the skill's exact-text fallback; don't invent capabilities or assert that references can be read.

## Synthesize before autonomous execution

For each authorized file-capable member or package-document assignment, use [Build-first agent preparation](agent-preparation.md), independent of the semantic model profile. Preserve explicit agent/tuple overrides, idle/input/full readback before one send and pure-read no-switch semantics. This is not permission to alter backend defaults, member scope, package gates or current runtime policy.

Before autonomous execution, reconcile the confirmed package into one **Synthesized Execution Contract** section in its canonical P. C carries the active `SYNTHESIS_REVISION`, phase, current candidate HEAD, receipt/evidence, blockers and next safe action. Existing members keep stable scope/evidence/acceptance and Board states. No new MCP/backend schema, contract store, execution engine or Board status is introduced; `synthesized` is document state.

Fill this minimum contract from actual current sources, not title matches or chat memory:

```text
Synthesized Execution Contract
package_id=<exact master task ID>; SYNTHESIS_REVISION=<positive package-local integer>
revision_state=<candidate or active>; supersedes=<prior revision or none>
sources=<exact member IDs, Board task revisions, canonical C/P paths + content revisions>
completed_evidence=<per-member original result/read coverage, source/integrated commits,
  test/QC subjects + results, unresolved acceptance; explicit imports from prior revision>
goal_semantics=<one shared goal and reconciled current semantics; superseded clauses>
dependencies_order=<named waves, required predecessor content, sequential/parallel prohibitions>
base_HEAD=<exact immutable integrated starting commit>; candidate_HEAD=<current subject>
writer_integration=<physical code/document roots, owners, actual tool targets,
  single integrator/publisher, shared/generated surfaces, source-to-target verification>
autonomous_decisions=<permitted in-scope technical choices and evidenced Board transitions>
test_integration_QC_gates=<checks, independent reviewer, full-candidate/external gates>
correction_loop=<eligible findings, separate fixer, fingerprint/history, bounded budget,
  focused checks/integration and renewed independent QC>
hard_stops=<new product/architecture/security/scope decision, unreconcilable base/owner,
  true host/operator permission, exhausted repair budget>
target_end_state=<package acceptance and READY_FOR_LOCAL_RELEASE_PREP criteria>
excluded_operator_only=<actual release/tag/remote push/publish/upload/deploy/productive
  restart, destructive cleanup, unauthorized host/security actions and other exclusions>
```

`SYNTHESIS_REVISION` starts at 1 for the first synthesis; a **candidate is inactive**. Pin pre-synthesis source bytes/revisions, then separately record publication readback revisions after ownership markers are written, avoiding self-referential hashes. One document owner publishes the contract and each member's `package_id`, `SYNTHESIS_REVISION`, `execution_owner=package` and canonical contract pointer in existing C/P. Activate only after package/member identity/revision/ownership agree and current readiness passes. Partial/uncertain publication blocks dependent dispatch: reread/reconcile the same documents, preserve newer content, never blindly replay or retarget. These are cooperating-workflow markers, not authentication, a lease or a cross-client exactly-once guarantee.

For an active revision, the **package master is sole dispatch owner**. Before any task-level dispatch, check canonical ownership markers and the owning package. Schedulers, other managers and another package referencing it consume package evidence; they must not separately start the synthesized member. Package ownership does not replace the concrete worker/worktree owner or existing single-flight/admission gates. Preserve action keys, actual session/submitted-message receipts and original results; already admitted work is observed and uncertain delivery reconciled, never resent through another session.

Completed/integrated implementation is imported as **completed evidence**, including unresolved member acceptance, and never redispatched wholesale in a new revision. Remaining review/external acceptance and explicitly scoped corrections are distinct obligations. New members remain **unsynthesized**, outside the active revision; neither a Board addition nor a new card silently changes membership, scope or gates. To include them, explicitly synthesize a new revision with exact sources, completed imports and superseded revision, reconcile existing admissions/base/owners and revalidate readiness. A real new dependency blocks affected work instead of silent absorption or omission. A revision change never resets repair history. Routine checkpoints/current HEAD/evidence update within the fixed revision; material membership/semantic/gate changes require a new revision and any genuine decision first.

### Dispatch precedence

For a proposed remaining member implementation step, apply the **first matching row** after canonical reads. These action labels describe reasoning, not tools/API arguments. All gates still apply to other phase actions.

| Condition | Action | Required behavior |
|---|---|---|
| Hard stop | INPUT_REQUIRED | New product/architecture/security/scope decision, unreconcilable base/ownership, true host/operator permission or exhausted bounded budget; preserve work and park dependent action. |
| Contract or readiness invalid | RECONCILE | Missing/conflicting sources, partial markers, stale base/owner or failed named-wave readiness: no dispatch from an old ready label. |
| Member outside active revision | KEEP_UNSYNTHESIZED | Preserve active contract; no member admission until an explicit new revision. |
| Caller is not package owner | OBSERVE_PACKAGE | Read/reconcile owning package; zero independent member dispatch. |
| Prior receipt admitted or uncertain | RECONCILE_RECEIPT | Observe admitted work or recover exact uncertain action/receipt/result; never resend. |
| Implementation already completed and integrated | IMPORT_COMPLETED_EVIDENCE | Preserve commits/results and separate acceptance; no whole-member rerun. |
| Remaining step ready | DISPATCH_ONCE | Package owner admits one bounded remaining step with exact member C/P, worker owner/base/target and receipt. |

### Package phases and correction loop

`SYNTHESIS -> READY -> IMPLEMENT/INTEGRATE -> INDEPENDENT_QC -> CORRECTION_LOOP -> FINAL_QC -> LOCAL_RELEASE_PREP -> OPERATOR_HANDOFF`

The correction stage is conditional and loops through renewed independent review. Within a valid authorized contract, commit-ready, integration-ready, QC-startable and permitted evidence-supported Board transitions/readback are **internal transitions**, not operator handoffs. Workers make safe small/medium reversible technical choices inside fixed architecture/scope/acceptance, record material assumptions and continue. A genuine hard stop returns terminal INPUT_REQUIRED with decision/context/options/completed/paused work; no native Question or security autoapproval. Missing required evidence stays PENDING, not invented PASS/FAIL.

Apply these transitions only with current owner/base/receipt evidence. The observed gate must actually pass; elapsed time, idle, Board Done or implementer claims alone are insufficient:

| Phase | Observed gate | Next phase | Required evidence/action |
|---|---|---|---|
| SYNTHESIS | contract verified | READY | All fields, source/completed imports and ownership markers consistent; registered documents and current named-wave readiness verified. |
| READY | admission ready | IMPLEMENT/INTEGRATE | Delta/JIT scope, dependencies, worker/tool targets/base, single-flight and exact receipt reconciliation. |
| IMPLEMENT/INTEGRATE | integration verified | INDEPENDENT_QC | All remaining waves integrated/checks recorded on exact combined candidate; imported completed waves need no dispatch. |
| INDEPENDENT_QC | in-scope finding | CORRECTION_LOOP | Unequivocally within unchanged contract/acceptance; available historical budget and separate correction owner. |
| INDEPENDENT_QC | independent PASS | FINAL_QC | Independent exact-subject evidence; no eligible local finding; retain every external PENDING. |
| CORRECTION_LOOP | correction integrated | INDEPENDENT_QC | Minimal fix/focused regression/integration, new exact subject and renewed independent reviewer; no self-acceptance. |
| FINAL_QC | in-scope finding | CORRECTION_LOOP | Same bounded classification; correction returns through renewed independent QC and full-candidate final gate. |
| FINAL_QC | final PASS | LOCAL_RELEASE_PREP | Mandatory independent full-candidate QC and all retained release gates PASS; zero release-blocking FAIL/PENDING establishes READY_FOR_LOCAL_RELEASE_PREP. |
| LOCAL_RELEASE_PREP | behavior changed | IMPLEMENT/INTEGRATE | Renew affected combined and independent full-candidate QC; local preparation cannot smuggle a fix. |
| LOCAL_RELEASE_PREP | local prep verified | OPERATOR_HANDOFF | Exact HEAD, aligned metadata/reproducible artifacts/checks and precise operator-only last steps; no actual publication. |

A reviewer evaluates, without automatic self-fix. The **contract may authorize the package** to route only unequivocally in-scope QC findings to a separate correction worker. Any separately authorized reviewer implementation role still needs a different independent reviewer. Reserve attempts at admission including uncertainty; preserve same/equivalent fingerprints, A→B→A, older history and pending reservations across restart/revision. Default at most two no-progress autonomous **production-code** repair cycles per equivalent fingerprint (management/read/result-fetch/receipt-reconciliation/docs/planning/tests/fixtures/harness/test-environment/infrastructure work is excluded and never counts or parks; evidenced progress ends the no-progress series), using [existing progress/counter rules](integration-test-monitor.md#fingerprint-counters-and-progress); focused PASS does not erase a recurring full failure. No weakened acceptance, blind resend or silent cap reset/extension. Exhaustion or a new product/architecture/security/scope choice yields INPUT_REQUIRED. Work park never stops scheduler cadence.

FINAL_QC must name exact full candidate HEAD, contract revision, relevant source/document/bundle revisions and independent reviewer. An implementer/fixer cannot supply its own independent acceptance; stale/pre-change or partial-candidate QC cannot pass the gate. Member acceptance, package acceptance, Board status, active revision and local-preparation readiness stay distinct. The package can autonomously reach READY_FOR_LOCAL_RELEASE_PREP when all gates pass; then use the repository's [release process](release-gates.md). Actual release/tag/remote push/publish/upload/deploy/productive restart, destructive cleanup and unauthorized host/security actions remain excluded/operator-only. Preserve the working runtime while release gates are red/unverified.

For migration of an existing package, first integrate the synthesis workflow member, then synthesize pilot revision 1 from the actual integrated candidate. Import completed predecessor and synthesis-member work with exact evidence and separate acceptance gaps; do not replay them. Additional independent **full-candidate FINAL QC after pilot synthesis** is mandatory even if the earlier local QC/fix cycle passed. Source/bundle, imported skill, discovered connector and hosted behavior remain separate evidence levels; synthesis cannot turn PENDING into PASS.

## Build the wave plan and evaluate `WORK_PACKAGE_READY`

### Lean package preparation

Apply the core **simple first / complexity on evidence** rule before fixing membership, waves or test/worktree needs. Unless already reliably answered, ask two short questions: “Are you currently the only human owner/coordinator of these code surfaces?” and “Is this package handled by one coordinated writing agent/monitor strand at a time?” Two yes answers without concrete counterevidence suffice for ordinary local ownership; no repository-wide writer search, global registry or process inventory. A brief optional Git-author sample is an anomaly signal, not ownership proof or human/bot classification. For other consequential unknowns (e.g. shared test service or extra integration stage), ask one targeted Spot-Check rather than assuming complexity. Preserve confirmed assumptions in C/P and member handoffs; later workers don't escalate them without new evidence.

Use a bundled preflight for current scope, source/HEAD, actual write target, known collision signals, early semantic product/trust/security decisions and acceptance needed for this step. Feature start needs start evidence; exact target/integrator/combined diffs belong immediately before integration; E2E/external acceptance/release checks belong in their phases. Delta-revalidate previously valid readiness, rather than repeating full package setup. Concrete concurrent writers or shared resources tighten only affected portions under the existing worktree rules; retain actual tool-target verification.

`WORK_PACKAGE_READY` is an orchestrator checkpoint in the package documents/result, not an OpenCode/MCP tool, Board column, permission grant, or synonym for `CONCEPT_READY`, `REGISTERED`, `BOARD_MOVED`, member completion, integration, or acceptance. Every checkpoint names the exact package ID, wave, relevant document revisions, integration target/base and excluded/parked members. It applies to the **named wave only**; later waves are reevaluated against their actual predecessor state.

Create explicit waves such as discovery/concept readiness, independent isolated implementation, serialized integration/reconciliation, combined regression and dependent implementation. For each member state dependencies, parallel/sequential classification, expected source base, required prior integrated HEAD, likely file/hunk/version/release overlap, worktree owner and verifier. If exact diff overlap is not yet knowable, classify the risk and do not promise conflict-free parallel work. One integrator owns the shared target tree; concurrent source work cannot update shared bundle/version state in that tree.

Mark the named wave `WORK_PACKAGE_READY` only when all applicable checks pass:

- membership, goal, exclusions, acceptance and authorization for that wave are explicit;
- every starting task is ready for its assigned analysis, concept, review or implementation scope and has current required task documents;
- task dependencies, expected basis and actual required prior integration are verifiable;
- simultaneous repository writers have separate usable persistent worktrees and unique repository-wide owners, or the plan deliberately sequences them; pure read-only members need no write worktree;
- for mutating members, tool-level file-write targeting is verified, not inferred from shell `workdir` or the prompt;
- likely shared-hunk, version, package, submodule, generated-output and test-service conflicts have an explicit order/reconciliation plan;
- integration owner/target, combined checks, checkpoints, retention and next handoff are specified;
- actual decisions and operator boundaries are settled, or the affected task is explicitly parked outside this wave;
- the latest package/membership/task-document/baseline observations are cited with time/source.

A ready wave does not imply all package tasks are ready. An unready member can remain `todo` or blocked while an independent ready wave proceeds. A member's blocked condition does not block independent work unless dependency or shared-state analysis shows that the other wave is unsafe.

Reject an empty/unknown-member wave, unresolved dependency cycle or dependency on an unverified result. Before each actual dispatch, resume or Board move, revalidate the named wave against current membership, relevant member/package document revisions, integration HEAD/content, ownership, pending input and authorized scope. A failed reevaluation invalidates its earlier ready evidence; a saved `WORK_PACKAGE_READY` label is not perpetual admission. Changes while a member is already executing pause/replan only affected dependent work at a safe checkpoint, never trigger a duplicate send, abort or forced reset. Already `in_progress` packages retain their actual Board status when a later wave is blocked; only the wave is parked. Do not roll the Board back to `todo` just to repeat readiness or registration.

After a dependency integrates, verify the real integration-tree `HEAD` and the presence of required content before starting downstream tasks. Update package C with the new target, resulting integration commit and actual checks. Retain done members in package membership and report their implementation/commit contribution even if external acceptance is outstanding.

## Monitored Work Packages v1

Normal Chat/Voice prepares the complete [Work/Worker bootstrap](monitor-tasks.md), never creates the schedule itself or silently executes a wrong-surface paste. Operator escalation is the worker's duty in both terminal report and uniquely identified package-master checkpoint: system/process/problem/impact, at least two concrete operational examples, then evidence/uncertainty/question; persist context/examples/reason/next permissible step consistently. Missing anchor means a management gap, no member-card guess. Work park/PASS/STOPPED retain scheduler cadence until expiry or explicit SCHEDULER stop. A current non-superseded canonical package decision, including a cross-chat Resume, releases only its bounded step after exact follow-up reconciliation and delta readiness; no separate provenance/register, no duplicate send or loop-history reset.

Use the package task as master under [Monitor Tasks](monitor-tasks.md), with the active synthesized contract above before autonomous package execution. Monitored v1 Waves are **strictly sequential**: only one wave active, no next mutating wave or parallel preparation/monitor strand for the same continuation while it runs. Do not parallelize solely because members seem independent. Existing generic parallel-work planning is not permission for Monitor v1 parallel Waves.

After Wave N's terminal original results are read, verify required integration/acceptance and the actually reached base/target HEAD/content. If integration/checks are pending, that remains Wave N management, not Wave N+1 readiness. Only then perform short delta/JIT `WORK_PACKAGE_READY` for Wave N+1: changed relevant documents/dependencies, scope/input, owner/tool target, base/content/resources and next-step acceptance. Reuse valid facts and record current revisions/HEAD; a source commit or Board Done alone does not pass. Dispatch at most one bounded management action through the common loop. A later wave's missing readiness/decision does not retroactively block or abort an earlier already-running wave, roll Board back to todo, or justify a duplicate send.

## Minimal-functional autonomy and decision parking

The package authorizes workers to make small/medium reversible engineering choices that stay inside its documented architecture, member task scope and acceptance criteria. Workers record material assumptions and continue to a safe implementable result; do not pause for each local coding choice. This does not authorize new product semantics, scope, security boundaries, core architecture, irreversible schema/data changes, remote publishing or out-of-scope product cleanup.

When a genuine decision exceeds the plan, the member worker must:

1. stop only the dependent portion in a recoverable state and retain its worktree/dirty changes;
2. return the normal terminal agent-managed `INPUT_REQUIRED` with the exact decision, context, safe options, completed work and paused work;
3. leave independent members running only when their bases, scopes and resources are verified independent;
4. let the orchestrator read that exact result, resolve the decision in Chat/Work with the user, check the original session is idle/no pending security input and send a normal authorized follow-up to that same session.

`INPUT_REQUIRED` is a completed turn, not business/task/package completion. Real host/security permission requests remain independent. Do not use native Question replies, create a second session to evade a busy/unresolved write or move Board state merely from turn completion. Only explicitly contract-permitted, evidence-supported transitions/readback are internal; no new column or acceptance coupling. Record the blocker and next decision in package C on the next authorized maintenance write.

## Morning Handoff without prior chat context

After a separately contract-authorized member Done transition, [archive follow-through](task-done-archive.md) checks all current repository references; an open master/package or another member still linked to that session blocks automatic archive. Secure result/handoff before eligibility/readback. No package/member Done from technical finish, no actual archive from this planning or implementation policy, and no exception to unresolved receipt/host/security guards. Keep member, package, archive and release states independent.

On return, start from the selected connector/project, package Board task, registered package C/P and exact member IDs. Read package C first and the plan only for needed dependency, design or integration detail. Re-read the live Board states and task document bindings; inspect required original session messages/results under the normal content protocol. Then verify each relevant worktree's physical path, Git root/common-dir, starting base, HEAD, branch, dirty/untracked state and owner, plus the actual integration target `HEAD`.

Summarize separately:

- member Board status and obligation still owed;
- session/receipt/tool observation, including unknown, busy, pending input and original-result coverage;
- implementation and actual test evidence;
- local source commits and uncommitted changes;
- integration source/target commit and combined-check state;
- external/Hosted/operator acceptance and who must perform it;
- retained worktrees, blockers and the next safe operation.

Neither an idle session nor Board `done` proves result review, integration or external acceptance. A local commit can remain `in_progress` while the agreed external acceptance is open. An integrated task worktree is not automatically safe to delete. Fresh VM history is not automatically restored: the existing default start is fresh; `--keep-history` is an operator option, not a promise. If a linked original result cannot be retrieved, report the evidence gap rather than repeating test claims from C. This is an on-demand handoff, not a watcher, scheduler or automatic morning notification.

## Chat, ChatGPT Work and OpenCode-VM are separate roles

Use ordinary Chat for interactive goal clarification, candidate selection, Readiness discussion, prioritization and later result review. After a named wave has reached `WORK_PACKAGE_READY`, the skill should direct a multi-step management run to a **ChatGPT Work** session when that surface, selected project and required app tools are actually available. If already in a suitable Work session, continue there. Otherwise give the user a clear Work-start instruction and a copy/paste handoff; the ordinary chat cannot silently turn itself into Work and the skill does not claim an automatic Work-invocation API.

ChatGPT Work coordinates the package and invokes the selected OpenCode project connection for repository work. The OpenCode VM remains the worker/runtime that reads or changes repository files, runs tests and creates local commits. Work availability depends on account/plan/workspace/surface; connected apps and their permissions are separate. If the selected Work surface cannot access the intended connection/tools, report that prerequisite and do not pretend an OpenCode task was sent. For UI labels/availability, consult the current [ChatGPT Work and Codex documentation](https://help.openai.com/en/articles/20001275-chatgpt-work-and-codex).

The documented ChatGPT model picker is separate from the project's OpenCode runtime profile. Do not translate an OpenCode provider/model/variant ID into a ChatGPT Work model or claim that `update_session_runtime` switches Work's model. The Work user selects a model available in that product surface; the profile capability below governs only an OpenCode worker when a submission to that runtime is being prepared.

## Choose and resolve the OpenCode management profile

Recommend a profile based on the whole management work package:

- **`execution`** — fixed member plans, ready waves and deterministic integration/checklist work;
- **`standard`** — ordinary multi-task coordination with bounded reconciliation;
- **`deep`** — uncertain architecture/dependencies, several serious Shared-Hunk conflicts or difficult integration diagnosis.

State one sentence explaining the recommendation. Discover `get_recommended_runtime` and its actual schema before using it. Resolve against current project policy; do not hard-code a provider, model, variant or OpenAI Work selection. An explicit user runtime/profile wins. The resolver skips only `null`, and the first configured unavailable/uncheckable/incomplete mapping is a stop, not permission to choose another configured profile. All-null/unconfigured may use the existing suitable OpenCode session default under the current skill contract.

For a new OpenCode work submission, apply the resolved exact tuple only to the chosen idle/no-pending-input session using the discovered runtime-update capability; preserve agent and omitted settings, read the session back, then send once. If the connection lacks profile/runtime tools, say so and use the existing suitable session only where the current submission contract permits; do not invent a tool, restart/restage a connector, or block ChatGPT Work pretending it can use the OpenCode tuple as its model.

## Compact Work-session bootstrap

Once ready, generate a small handoff rather than copying the package description or plan:

```text
Coordinate Work Package <package_task_id> for project <verified project/connection>.

Package C: <exact registered compact_context path>
Package P: <exact registered concept_plan path>
Gate: WORK_PACKAGE_READY for <named wave> on <verified base HEAD>.
Contract: SYNTHESIS_REVISION <active revision>; execution_owner=package;
exact sources/completed evidence/exclusions and phase: <canonical package P section>.

Read the Board task, C and P first. Verify the package/member documents and
current Board/result evidence; the files define scope and plan, originals prove
execution. The package master alone dispatches active-revision members; import
completed evidence without rerun, keep new members unsynthesized until a new revision.
Before writes, verify the task's owner, persistent worktree, base HEAD,
dirty state and actual file-tool target. Follow the planned wave/integrator; do
not start dependencies on an older HEAD. Update C after substantive milestones;
update P only for real concept changes. Make safe in-plan technical decisions
autonomously; return terminal INPUT_REQUIRED and park dependent work for a
plan-exceeding decision. No remote Git write/push. Report implementation,
tests, commits, integration and external acceptance separately.
```

The assistant should confirm the exact package/wave, the C/P actually read, the verified owner/base, the OpenCode connection it can use and its next safe step. That is an acknowledgement, not proof that any member started. Capture each actual OpenCode submission's receipt and original result using the usual per-session contract; do not assume queueing or issue a second send after an uncertain response.

Before a Work handoff, show the profile recommendation/reason and currently resolvable runtime or explicit capability/availability gap. In the destination, revalidate readiness and the connection; for every actual member submission include that member's stable task ID, exact established C/P paths, canonical document root and code worktree/owner/base. Use the existing full-care briefing once in a new executing context and the short reminder for ordinary follow-ups. The package-only bootstrap does not replace member-specific task-file handoffs.

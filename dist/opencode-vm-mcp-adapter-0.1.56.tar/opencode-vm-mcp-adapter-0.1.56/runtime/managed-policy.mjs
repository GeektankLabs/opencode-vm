import { createServer } from "node:http";
import { connect } from "node:net";
import { mkdir, readFile, writeFile, rename, lstat, realpath, unlink, chmod } from "node:fs/promises";
import { dirname, join, normalize as normalizePath, relative, resolve } from "node:path";
import { createHash } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { policyDelta, remoteWrite, tokens, handback, permissionBlocker, PRIMER, COMMIT_SENTENCE, LEGACY_VM_ASK, MANAGED_VM_ASK, protocol, questionInResponse, responseUsage, terminalResponse, matchesGlob, mergeScopeDirs, orderSweepAsks, REVISION } from "./managed-core.mjs";

const FETCH_STATE = Symbol.for("ocvm.managed.fetch.v1");
const HEADER = "x-ocvm-managed-turn";
const MAX_STEP_BYTES = 8 * 1024 * 1024;
const SUPPORTED = /(?:openai|anthropic|azure|google|openrouter|xai|mistral|groq|deepinfra|cerebras|togetherai|perplexity|alibaba|venice|copilot|amazon-bedrock\/mantle)/;
const exec = promisify(execFile);

// Operator-authorized external directory scope, declared per session at
// adoption. Bounded, absolute, normalized; never a blanket allow.
function normalizeScopeDirs(dirs) {
  if (!Array.isArray(dirs)) throw new Error("MANAGED_SCOPE_INVALID");
  if (dirs.length > 16) throw new Error("MANAGED_SCOPE_LIMIT");
  return dirs.map(dir => {
    if (typeof dir !== "string" || dir.length > 512 || dir.includes("\0") || /[\r\n]/.test(dir)) throw new Error("MANAGED_SCOPE_INVALID");
    if (!dir.startsWith("/")) throw new Error("MANAGED_SCOPE_INVALID");
    const normalized = normalizePath(dir);
    if (normalized === "/" || normalized.includes("..")) throw new Error("MANAGED_SCOPE_INVALID");
    return normalized.replace(/\/+$/, "") || "/";
  });
}

async function normalizeReadFiles(files) {
  if (!Array.isArray(files) || files.length > 16) throw new Error("MANAGED_SCOPE_INVALID");
  for (const file of files) {
    if (typeof file !== "string" || file.length > 512 || !file.startsWith("/") || file === "/" ||
        /[\x00-\x1f\x7f*?\[\]{}\\]/.test(file) || normalizePath(file) !== file || file.endsWith("/")) throw new Error("MANAGED_SCOPE_INVALID");
    const info = await lstat(file).catch(() => null);
    if (!info?.isFile() || info.isSymbolicLink() || await realpath(file) !== file) throw new Error("MANAGED_SCOPE_INVALID");
  }
  return [...new Set(files)];
}

// Gate one provider step before the SDK can dispatch a native Question. The
// terminal stream is consumed/persisted/completed by the real OpenCode runner;
// no DB mutation, question reply, session abort, model retry or fake user turn.
function installCompletionGate() {
  if (globalThis[FETCH_STATE]) return globalThis[FETCH_STATE];
  const original = globalThis.fetch;
  const state = { turns: new Map() };
  globalThis[FETCH_STATE] = state;
  globalThis.fetch = async (input, init) => {
    const headers = new Headers(init?.headers ?? (input instanceof Request ? input.headers : undefined));
    const key = headers.get(HEADER);
    if (!key) return original(input, init);
    headers.delete(HEADER); // never disclose local correlation to a model provider
    const turn = state.turns.get(key);
    if (!turn) throw new Error("MANAGED_COMPLETION_TURN_UNKNOWN");
    const bodyText = init?.body ?? (input instanceof Request ? await input.clone().text() : "{}");
    let body;
    try { body = JSON.parse(bodyText); } catch { throw new Error("MANAGED_COMPLETION_REQUEST_INVALID"); }
    const url = String(input instanceof Request ? input.url : input);
    const kind = protocol(body, url, turn.family);
    if (!kind) throw new Error("MANAGED_COMPLETION_PROTOCOL_UNSUPPORTED");
    const streaming = body.stream !== false && !url.includes(":generateContent");
    if (turn.report) return terminalResponse(turn.report, kind, streaming);
    const response = await original(input, { ...init, headers });
    if (!response.ok || !response.body) return response;
    const reader = response.body.getReader();
    const chunks = [];
    let bytes = 0;
    try {
      for (;;) {
        const part = await reader.read();
        if (part.done) break;
        bytes += part.value.byteLength;
        if (bytes > MAX_STEP_BYTES) throw new Error("MANAGED_COMPLETION_STEP_LIMIT");
        chunks.push(part.value);
      }
    } catch (error) { await reader.cancel().catch(() => {}); throw error; }
    const raw = Buffer.concat(chunks.map(c => Buffer.from(c)));
    const blocked = questionInResponse(raw.toString("utf8"), kind);
    if (blocked) {
      turn.report = blocked.report;
      return terminalResponse(turn.report, kind, streaming, responseUsage(raw.toString("utf8"), kind));
    }
    return new Response(raw, { status: response.status, statusText: response.statusText, headers: response.headers });
  };
  return state;
}

export default async ({ client, directory, worktree }) => {
  const socket = process.env.OCVM_MANAGED_POLICY_SOCKET;
  if (!socket) return {}; // ordinary standalone OpenCode remains unchanged
  const project = resolve(directory);
  const hash = createHash("sha256").update(project).digest("hex");
  const store = join(process.env.XDG_DATA_HOME ?? join(process.env.HOME, ".local/share"), "opencode", "managed-sessions", `${hash}.json`);
  await mkdir(dirname(store), { recursive: true, mode: 0o700 });
  let saved = { schema: 1, project, sessions: {} };
  try {
    const info = await lstat(store);
    if (!info.isFile() || info.isSymbolicLink() || info.size > 4 * 1024 * 1024) throw new Error("MANAGED_STATE_INVALID");
    saved = JSON.parse(await readFile(store, "utf8"));
    if (saved.schema !== 1 || saved.project !== project || !saved.sessions || typeof saved.sessions !== "object" || Array.isArray(saved.sessions)) throw new Error("MANAGED_STATE_INVALID");
  } catch (error) { if (error.code !== "ENOENT") throw error; }
  const fetchState = installCompletionGate();
  // PluginInput uses the legacy SDK (nested path params, old generated schema).
  // Its raw client preserves OpenCode's authenticated/in-process fetch while
  // addressing the verified V1 native endpoints explicitly.
  const api = async (method, url, body, query = {}) => {
    const result = await client._client.request({ method, url, query: { directory, ...query }, ...(body === undefined ? {} : { body, headers: { "content-type": "application/json" } }), throwOnError: true });
    return result.data;
  };
  const turnKeys = new Set();
  let queue = Promise.resolve();
  const serial = operation => { const next = queue.then(operation); queue = next.catch(() => {}); return next; };
  const persist = async () => {
    const tmp = `${store}.${process.pid}.tmp`;
    await writeFile(tmp, JSON.stringify(saved), { mode: 0o600 });
    await rename(tmp, store);
  };
  const getSession = async id => {
    if (typeof id !== "string" || !/^ses_[A-Za-z0-9_-]{1,250}$/.test(id)) throw new Error("MANAGED_SESSION_INVALID");
    const info = await api("GET", `/session/${id}`);
    const location = info?.directory ?? info?.location?.directory;
    if (!info || typeof location !== "string" || resolve(location) !== project || info.time?.archived) throw new Error("MANAGED_SESSION_NOT_EXPOSED");
    return info;
  };
  const idle = async id => {
    const [status, questions, permissions] = await Promise.all([api("GET", "/session/status"), api("GET", "/question"), api("GET", "/permission")]);
    if ([...(questions ?? []), ...(permissions ?? [])].some(item => item.sessionID === id)) throw new Error("MANAGED_INPUT_PENDING");
    if (status?.[id]?.type && status[id].type !== "idle") throw new Error("MANAGED_SESSION_BUSY");
  };
  const prepare = async (id, agentName, checkIdle = false, scopeDirs = [], scopeReadFiles = []) => {
    const info = await getSession(id);
    if (checkIdle) await idle(id);
    const [agents, config] = await Promise.all([api("GET", "/agent"), api("GET", "/config")]);
    const agent = agents.find(item => item.name === (agentName ?? info.agent ?? config.default_agent ?? "build"));
    if (!agent || agent.name === "openlive-manager") throw new Error("MANAGED_AGENT_INVALID");
    const current = info.permission ?? [];
    const previous = saved.sessions[id];
    const entry = previous ? structuredClone(previous) : { revision: REVISION, adoptedAt: new Date().toISOString(), base: current, disabled: {}, scopeDirs: [], scopeReadFiles: [], lastNative: current };
    if (entry.revision !== REVISION || !Array.isArray(entry.base) || !Array.isArray(entry.lastNative) ||
        typeof entry.disabled !== "object" || entry.disabled === null || Array.isArray(entry.disabled)) throw new Error("MANAGED_STATE_REVISION_UNSUPPORTED");
    // Writers before the scopeDirs field persisted otherwise-valid entries
    // without it. Normalize ONLY a genuinely absent field on a strictly
    // validated same-revision entry to an empty scope — no external access is
    // granted, all stored rules/denies/disables stay verbatim. A present-but-
    // invalid value still fails closed. The migrated entry is persisted even
    // when the policy delta is empty, so the lazy one-time normalization
    // survives a restart instead of re-failing every adoption.
    let migrated = false;
    if (previous && previous.scopeDirs === undefined) {
      if (entry.revision !== REVISION || typeof entry.disabled !== "object" || entry.disabled === null || Array.isArray(entry.disabled)) throw new Error("MANAGED_STATE_REVISION_UNSUPPORTED");
      entry.scopeDirs = [];
      migrated = true;
    } else if (previous && !Array.isArray(previous.scopeDirs)) throw new Error("MANAGED_STATE_REVISION_UNSUPPORTED");
    if (previous && previous.scopeReadFiles === undefined) { entry.scopeReadFiles = []; migrated = true; }
    else if (!Array.isArray(entry.scopeReadFiles)) throw new Error("MANAGED_STATE_REVISION_UNSUPPORTED");
    // New and reused children receive newly declared parent scope before work.
    const parent = info.parentID ? saved.sessions[info.parentID] : null;
    const priorScope = JSON.stringify([entry.scopeDirs, entry.scopeReadFiles]);
    entry.scopeDirs = mergeScopeDirs(entry.scopeDirs ?? [], parent?.scopeDirs ?? []);
    entry.scopeDirs = mergeScopeDirs(entry.scopeDirs ?? [], normalizeScopeDirs(scopeDirs));
    entry.scopeReadFiles = mergeScopeDirs(entry.scopeReadFiles, parent?.scopeReadFiles ?? []);
    entry.scopeReadFiles = mergeScopeDirs(entry.scopeReadFiles, await normalizeReadFiles(scopeReadFiles));
    if (entry.scopeReadFiles.length && (typeof worktree !== "string" || !worktree.startsWith("/"))) throw new Error("MANAGED_READ_CONTEXT_UNKNOWN");
    const readFiles = entry.scopeReadFiles.map(file => ({ file, pattern: relative(worktree, file) }));
    const prefix = entry.lastNative.every((r, i) => current[i]?.permission === r.permission && current[i]?.pattern === r.pattern && current[i]?.action === r.action);
    if (!prefix) throw new Error("MANAGED_POLICY_REPLACED_EXTERNALLY");
    // Actual external PATCH appends are preserved separately from our owned
    // blocks. Re-applying/changing an agent never adopts our own previous rules
    // as new task restrictions and never accumulates on an unchanged readback.
    entry.base = [...entry.base, ...current.slice(entry.lastNative.length)];
    const scope = [...entry.base, ...Object.entries(entry.disabled).filter(([, value]) => value).map(([permission]) => ({ permission, pattern: "*", action: "deny" }))];
    const delta = policyDelta(current, agent.permission ?? [], scope, entry.scopeDirs, readFiles);
    if (delta.length) {
      await api("PATCH", `/session/${id}`, { permission: delta });
      const verified = await getSession(id);
      if (policyDelta(verified.permission ?? [], agent.permission ?? [], scope, entry.scopeDirs, readFiles).length) throw new Error("MANAGED_POLICY_READBACK_FAILED");
      entry.lastNative = verified.permission ?? [];
    }
    if (!saved.sessions[id] || delta.length || migrated || priorScope !== JSON.stringify([entry.scopeDirs, entry.scopeReadFiles])) {
      saved.sessions[id] = entry;
      try { await persist(); }
      catch (error) { if (previous) saved.sessions[id] = previous; else delete saved.sessions[id]; throw error; }
    }
    return { session_id: id, revision: REVISION, agent_managed: true, scope_read_files: entry.scopeReadFiles };
  };
  const isManaged = async id => {
    const seen = new Set();
    for (let depth = 0; depth < 32; depth++) {
      if (saved.sessions[id]) return true;
      if (seen.has(id)) throw new Error("MANAGED_PARENT_CYCLE");
      seen.add(id);
      const info = await getSession(id);
      if (info.agent === "openlive-manager") return false;
      if (!info.parentID) return false;
      id = info.parentID;
    }
    throw new Error("MANAGED_PARENT_LIMIT");
  };
  const deniedWrite = async (command, cwd = directory) => {
    if (remoteWrite(command)) return true;
    if (!command.includes("git")) return false;
    const words = tokens(command);
    const prefixes = [[]];
    for (let i = 0; i < words.length; i++) {
      if (words[i].split("/").at(-1) !== "git") continue;
      const prefix = [];
      for (let j = i + 1; j < words.length && words[j].startsWith("-"); j++) {
        prefix.push(words[j]);
        if (["-C", "-c", "--git-dir", "--work-tree", "--exec-path", "--config-env"].includes(words[j])) prefix.push(words[++j]);
      }
      prefixes.push(prefix);
    }
    if (prefixes.length > 16) throw new Error("REMOTE_POLICY_COMMAND_LIMIT");
    for (const prefix of prefixes) {
      let output;
      try { output = (await exec("git", [...prefix, "config", "--null", "--get-regexp", "^alias\\."], { cwd, timeout: 2000, maxBuffer: 64 * 1024 })).stdout; }
      catch (error) { if ([1, 128].includes(error.code)) continue; throw error; }
      const aliases = {};
      for (const record of output.split("\0")) {
        const newline = record.indexOf("\n");
        if (newline >= 0) aliases[record.slice(6, newline)] = record.slice(newline + 1);
      }
      if (remoteWrite(command, aliases)) return true;
    }
    return false;
  };

  await mkdir(dirname(socket), { recursive: true, mode: 0o700 });
  try {
    const info = await lstat(socket);
    if (!info.isSocket() || info.isSymbolicLink() || info.uid !== process.getuid()) throw new Error("MANAGED_SOCKET_UNSAFE");
    const alive = await new Promise(res => { const c = connect(socket); c.once("connect", () => { c.destroy(); res(true); }); c.once("error", () => res(false)); });
    if (alive) throw new Error("MANAGED_SOCKET_ALREADY_OWNED");
    await unlink(socket);
  } catch (error) { if (error.code !== "ENOENT") throw error; }
  const server = createServer(async (req, res) => {
    try {
      if (req.method === "GET" && req.url === "/health") {
        res.setHeader("content-type", "application/json");
        res.end(JSON.stringify({ revision: REVISION, project })); return;
      }
      if (req.method !== "POST" || req.url !== "/adopt") throw new Error("MANAGED_OPERATION_INVALID");
      let body = "";
      for await (const chunk of req) { body += chunk; if (body.length > 32768) throw new Error("MANAGED_REQUEST_LIMIT"); }
      const input = JSON.parse(body);
      if (!["mcp", "openlive", "a2a"].includes(input.ingress)) throw new Error("MANAGED_INGRESS_INVALID");
      const scopeDirs = input.scope_dirs === undefined ? [] : normalizeScopeDirs(input.scope_dirs);
      const scopeReadFiles = input.scope_read_files === undefined ? [] : await normalizeReadFiles(input.scope_read_files);
      const result = await serial(() => prepare(input.session_id, undefined, true, scopeDirs, scopeReadFiles));
      // Existing A2A/OpenLive clients retain the compact legacy reply; the
      // exact-file echo is required only by an explicit file declaration.
      if (input.scope_read_files === undefined) delete result.scope_read_files;
      res.setHeader("content-type", "application/json"); res.end(JSON.stringify(result));
    } catch (error) { res.statusCode = 409; res.end(JSON.stringify({ error: String(error.message).slice(0, 200) })); }
  });
  await new Promise((yes, no) => { server.once("error", no); server.listen(socket, yes); });
  await chmod(socket, 0o600);
  // Native permission asks (e.g. external_directory) have no plugin hook and
  // would wait forever on an interactive reply. Mirror `opencode run`'s
  // noninteractive precedent (auto-reject via the reply API), add corrective
  // feedback, and terminate the affected managed turn through the completion
  // gate so the blocker is a stored terminal report — never a hidden UI wait.
  // Manual sessions stay interactive; no managed Ask is automatically allowed.
  const asked = new AbortController();
  // Shared reject+terminal-report handling for one pending external ask.
  // Empty/absent ask patterns are NEVER authorized (fail closed into the
  // terminal blocker instead of a hidden wait). A transient isManaged API
  // error schedules ONE bounded delayed re-check (max 3 per ask, 1.5 s apart)
  // instead of relying on a future event resubscribe — an intact event stream
  // never reconnects on its own, so without this the ask could wait forever.
  const askRechecks = new Map();
  const scheduleAskRecheck = info => {
    if (asked.signal.aborted) return;
    const attempts = askRechecks.get(info.id) ?? 0;
    if (attempts >= 3) return;
    askRechecks.set(info.id, attempts + 1);
    const timer = setTimeout(() => { void sweepPendingAsks(); }, 1500);
    timer.unref?.();
  };
  const rejectingAsks = new Set();
  const rejectedAsks = new Set();
  const rejectUnauthorizedAsk = async info => {
    if (typeof info?.permission !== "string" || typeof info.sessionID !== "string" || typeof info.id !== "string") return false;
    if (rejectingAsks.has(info.id) || rejectedAsks.has(info.id)) return false;
    let managed = true;
    try { managed = await isManaged(info.sessionID); }
    catch { scheduleAskRecheck(info); return false; }
    if (!managed) return false;
    if (rejectingAsks.has(info.id) || rejectedAsks.has(info.id)) return false;
    rejectingAsks.add(info.id);
    const patterns = Array.isArray(info.patterns) && info.patterns.length ? info.patterns : (info.metadata?.parentDir ? [`${info.metadata.parentDir}/*`] : []);
    const report = permissionBlocker({ ...info, patterns });
    // Arm the completion gate BEFORE replying: resolving the pending
    // Deferred immediately unblocks the runner into its next provider
    // step, which must already see the terminal report.
    for (const key of turnKeys) {
      const turn = fetchState.turns.get(key);
      if (turn?.sessionID === info.sessionID) turn.report ??= report;
    }
    try {
      await api("POST", `/permission/${encodeURIComponent(info.id)}/reply`, { reply: "reject", message: "This permission is not authorized for the managed turn; end with a readable blocker. No permission was approved." });
      rejectedAsks.add(info.id);
      if (rejectedAsks.size > 2048) rejectedAsks.delete(rejectedAsks.values().next().value);
      askRechecks.delete(info.id);
    } catch { scheduleAskRecheck(info); }
    finally { rejectingAsks.delete(info.id); }
    return true;
  };
  // Bounded fail-open reconciliation: asks that appeared while the event
  // subscription was down, or whose lineage check hit a transient API error,
  // are swept from the pending list. Managed-session asks are ordered first
  // (fairness) so foreign/manual volume cannot starve the sweep's own line
  // behind the bound; anything beyond the bound is retried by the next
  // sweep/re-check. No scheduling architecture, no automatic allow, no touch
  // of manual sessions.
  const sweepPendingAsks = async () => {
    try {
      const pending = await api("GET", "/permission");
      if (!Array.isArray(pending)) return;
      for (const info of orderSweepAsks(pending, Object.keys(saved.sessions)).slice(0, 64)) await rejectUnauthorizedAsk(info);
    } catch { /* transient backend read: the next (re)subscribe or re-check sweeps again */ }
  };
  const watchAsks = (async () => {
    for (;;) {
      try {
        const subscription = await client.event.subscribe({ directory }, { signal: asked.signal });
        await sweepPendingAsks();
        for await (const event of subscription.stream) {
          if (event?.type !== "permission.asked") continue;
          await rejectUnauthorizedAsk(event.properties?.info ?? event.properties);
        }
      } catch (error) {
        if (asked.signal.aborted) return;
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
  })();
  return {
    dispose: async () => {
      asked.abort();
      for (const key of turnKeys) fetchState.turns.delete(key);
      await new Promise(res => server.close(res));
      await unlink(socket).catch(() => {});
    },
    "chat.message": async ({ sessionID }, { message }) => {
      if (!await isManaged(sessionID)) return;
      await serial(async () => {
        await prepare(sessionID, message.agent);
        if (message.tools && Object.keys(message.tools).length) {
          const visible = { ...message.tools };
          // V1 would otherwise replace *all* session rules after this hook.
          // Mutate that original input object; keep controls on the stored user
          // message and persist explicit disables through our own rule owner.
          for (const [tool, enabled] of Object.entries(visible)) {
            if (tool !== "question") saved.sessions[sessionID].disabled[tool] = enabled === false;
            delete message.tools[tool];
          }
          message.tools = visible;
          await prepare(sessionID, message.agent);
        }
      });
    },
    "experimental.chat.system.transform": async ({ sessionID }, output) => {
      if (sessionID && await isManaged(sessionID)) {
        for (let i = 0; i < output.system.length; i++) output.system[i] = output.system[i].replace(LEGACY_VM_ASK, MANAGED_VM_ASK).replace(COMMIT_SENTENCE, "");
        output.system.push(PRIMER);
      }
    },
    "tool.definition": async ({ toolID }, output) => {
      if (toolID === "bash" && output.description.includes(COMMIT_SENTENCE)) output.description = output.description.replace(COMMIT_SENTENCE, "");
    },
    "chat.headers": async ({ sessionID, message, model, agent }, output) => {
      if (agent === "openlive-manager" || ["title", "summary", "compaction"].includes(agent) || !await isManaged(sessionID)) return;
      if (!SUPPORTED.test(model.api.npm)) throw new Error(`MANAGED_COMPLETION_TRANSPORT_UNSUPPORTED: ${model.api.npm}`);
      const key = `${hash}:${sessionID}:${message.id}`;
      fetchState.turns.set(key, fetchState.turns.get(key) ?? { sessionID, userID: message.id, family: model.api.npm });
      turnKeys.add(key);
      output.headers[HEADER] = key;
    },
    "tool.execute.before": async ({ tool, sessionID }, { args }) => {
      if (!await isManaged(sessionID)) return;
      if (tool === "task" && args.task_id) {
        const parent = saved.sessions[sessionID];
        await serial(() => prepare(args.task_id, undefined, true, parent?.scopeDirs ?? [], parent?.scopeReadFiles ?? []));
      }
      if (tool === "read" || tool === "invalid" && args.tool === "read") {
        const entry = saved.sessions[sessionID];
        const file = typeof args.filePath === "string" ? resolve(directory, args.filePath) : null;
        const pattern = file && typeof worktree === "string" ? relative(worktree, file) : null;
        const action = pattern && entry?.lastNative.findLast(rule => matchesGlob("read", rule.permission) && matchesGlob(pattern, rule.pattern))?.action;
        let invalid = false;
        if (file && entry?.scopeReadFiles?.includes(file)) {
          try { await normalizeReadFiles([file]); } catch { invalid = true; }
        }
        if (tool === "invalid" || action === "ask" || action === "deny" || invalid) {
          const report = permissionBlocker({ permission: "read", patterns: pattern ? [pattern] : [] });
          for (const key of turnKeys) { const turn = fetchState.turns.get(key); if (turn?.sessionID === sessionID) turn.report ??= report; }
          throw new Error("INPUT_REQUIRED: managed Read permission blocked without interactive approval");
        }
      }
      if (tool === "question" || tool === "invalid" && args.tool === "question") {
        for (const key of turnKeys) { const turn = fetchState.turns.get(key); if (turn?.sessionID === sessionID) turn.report = handback(args.questions); }
        throw new Error("INPUT_REQUIRED: business question suppressed by the managed completion gate");
      }
      if (tool === "bash" && await deniedWrite(args.command ?? "", args.workdir ?? directory)) throw new Error("REMOTE_WRITE_DENIED: publishing is operator-only, not approvable in the guest");
    },
    "shell.env": async ({ sessionID, callID }) => {
      if (!sessionID || !await isManaged(sessionID)) return;
      // Native /shell does not call tool.execute.before. It stores this exact
      // call before shell.env and before spawning: read that correlation, not
      // a shared current-command variable or a permission-cache decision.
      const history = await api("GET", `/session/${sessionID}/message`, undefined, { limit: 20 });
      const part = history.flatMap(item => item.parts ?? []).findLast(item => item.type === "tool" && item.callID === callID && item.state?.status === "running");
      if (!part || typeof part.state?.input?.command !== "string") throw new Error("MANAGED_SHELL_CORRELATION_UNAVAILABLE");
      if (await deniedWrite(part.state.input.command, part.state.input.workdir ?? directory)) throw new Error("REMOTE_WRITE_DENIED: direct shell publishing is operator-only");
    },
  };
};
